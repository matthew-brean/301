/*******************************************************************************
* Created by: Matthew Brean
* Created on: 2019-10-20
* Created for: ICS4U
* Daily Assignment: #3-01
* reverse a string
*******************************************************************************/
import java.util.Scanner;
public class ReverseString 
{
    public static String reverse(String str) 
    {     
        if ((str==null)||(str.length() <= 1)) {
            return str;
        }
        
        return reverse(str.substring(1)) + str.charAt(0);
    }
    
    public static void main(String[] args) 
    {
    	@SuppressWarnings("resource")
		Scanner SCAN = new Scanner(System.in);
    	System.out.println("Enter a string to reverse: ");
		String stringToReverse = SCAN.nextLine();
        String str = stringToReverse;
        System.out.println("Reverse of "+str+" is "+reverse(str));    
    }    
}